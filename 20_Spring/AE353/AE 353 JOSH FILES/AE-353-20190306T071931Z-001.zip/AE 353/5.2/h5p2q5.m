syms k1 k2
K = [k1 k2]
denom = -C*inv(A-B*K)*B