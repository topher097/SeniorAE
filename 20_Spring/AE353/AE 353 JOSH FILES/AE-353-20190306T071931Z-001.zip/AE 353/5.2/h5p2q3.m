Q = eye(size(A))/r
disp(mat2str(Q))