Q = eye(size(A))*q
disp(mat2str(Q))