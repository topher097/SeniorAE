Q = transpose(C)*C;
disp(mat2str(Q))
