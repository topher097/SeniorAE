w = pi/pTime
s = log(pOver)/pTime
p = [(s) + w*i, (s) - w*i]
mat2str(p)