K = place(A,B,p)
mat2str(K)