denom = -C*inv(A-B*K)*B
kRef = 1/denom

E = (A - B*K)
F = B*kRef
F2 = B;
G = C;
H1 = [0];
H2 = [0];