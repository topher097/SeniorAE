denom = -C*inv(A-B*K)*B
kRef = 1/denom