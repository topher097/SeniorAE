E = (A - B*K)
F = B*kRef