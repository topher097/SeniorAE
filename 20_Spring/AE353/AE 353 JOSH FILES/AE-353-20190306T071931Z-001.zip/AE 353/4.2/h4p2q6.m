Wccf = ctrb(F,G)
W = ctrb(A,B)
K = L*Wccf*inv(W)
mat2str(K)