a = charpoly(A)
a = a(2:end)
mat2str(a)
