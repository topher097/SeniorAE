L = acker(A',C',p)';
disp(mat2str(L))