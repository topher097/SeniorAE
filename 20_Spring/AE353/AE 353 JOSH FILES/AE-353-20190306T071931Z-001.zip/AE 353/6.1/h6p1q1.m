F = A - L*C;
disp(mat2str(F))