K = lqr(A,B,Q,R)
disp(mat2str(K,6))