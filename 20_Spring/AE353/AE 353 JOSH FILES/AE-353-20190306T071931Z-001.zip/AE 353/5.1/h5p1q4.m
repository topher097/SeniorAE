[K,P] = lqr(A,B,Q,R)
u_t0 = -K*x0