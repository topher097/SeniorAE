% Write all necessary commands to run your simulation in this script. The
% bare minimum has been provided, but feel free to add whatever you wish.

DesignProblem01('Controller')

% Also, be considerate of your reviewers' time and memory when making
% choices about what to include here. Please do not write scripts that
% create massive matrices or take 10+ minutes to run once.